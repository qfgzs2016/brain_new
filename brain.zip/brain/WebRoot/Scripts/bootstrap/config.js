﻿var token = "2";
var webroot = "http://test.com";
var wechatapiurl = "http://img.com";
var pagesize = 10;
var pageNumSize = 5;
var userID = '1';
var imgurl = "http://admin.sokobo.cn";

var webroot_News = webroot + "/Ashx/MQET_News.ashx";
